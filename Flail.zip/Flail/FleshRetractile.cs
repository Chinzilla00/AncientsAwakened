using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Microsoft.Xna.Framework.Graphics;
using Terraria.ModLoader;
using System;

namespace AAMod.OtherModWork
{
    public class FleshRetractile : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Flesh Retractile");
            Tooltip.SetDefault("Throws a ravager claw that shreds through your targets");
        }

        public override void SetDefaults()
        {
            item.width = 38;
            item.height = 38;
            item.damage = 95;
            item.noMelee = true;
            item.noUseGraphic = true;
            item.channel = true;
            item.autoReuse = true;
            item.melee = true;
            item.useAnimation = 15;
            item.useTime = 15;
            item.useStyle = 5;
            item.knockBack = 2f;
            item.UseSound = SoundID.Item116;
            item.value = Item.buyPrice(1, 0, 0, 0);
            item.shoot = mod.ProjectileType("FleshRetractileProj");
            item.shootSpeed = 16f;
            item.rare = 8;
		}
	}
}
